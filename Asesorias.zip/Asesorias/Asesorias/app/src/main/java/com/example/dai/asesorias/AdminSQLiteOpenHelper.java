package com.example.dai.asesorias;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


//se crea para poder hacer la base de datos
public class AdminSQLiteOpenHelper extends SQLiteOpenHelper{
    public AdminSQLiteOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //Crear tablas del modelo
        sqLiteDatabase.execSQL("create table usuario (cu integer primary key, nombre text, apellidos text, edad integer, mail text, carrera text, contrasena text);");
        sqLiteDatabase.execSQL("create table profesor (cProfesor integer primary key, nombre text, apellidos text, mail text, tipo text);");
        sqLiteDatabase.execSQL("create table materia (cMateria integer primary key, nombre text, tipo text);");
        sqLiteDatabase.execSQL("create table clase (cClase integer primary key, cMateria integer references materia(cMateria), cProfesor integer references profesor(cProfesor), horario integer, dia text, cupo integer, inscritos integer, lugar text);");
        sqLiteDatabase.execSQL("create table calificacion (cu integer references usuario(cu), cProfesor integer references profesor(cProfesor), puntaje integer, comentario text, primary key (cu, cProfesor));");
        sqLiteDatabase.execSQL("create table inscrito (cClase integer references clase(cClase), cu integer references usuario(cu), primary key (cClase, cu));");
        //Profesores determinados para ponerlos en la aplicación
        sqLiteDatabase.execSQL("insert into profesor values (023, 'Ricardo', 'Meadowcroft', 'rmeadowc@itam.mx', 'estudiante');");
        sqLiteDatabase.execSQL("insert into profesor values (011, 'Ana Lidia', 'Franzoni', 'alidia@itam.mx', 'profesor');");
        sqLiteDatabase.execSQL("insert into profesor values (123, 'Roberto', 'Tello', 'tyo@itam.mx', 'laboratorista');");
        sqLiteDatabase.execSQL("insert into profesor values (124, 'Sofia', 'Occhipinti', 'sofi@itam.mx', 'estudiante');");
        sqLiteDatabase.execSQL("insert into profesor values (125, 'Caro', 'Marti', 'carmar@itam.mx', 'laboratorista');");
        sqLiteDatabase.execSQL("insert into profesor values (126, 'Estela', 'Romero', 'romero@itam.mx', 'profesor');");
        sqLiteDatabase.execSQL("insert into profesor values (127, 'Michelle', 'Desdier', 'desdier@itam.mx', 'estudiante');");
        sqLiteDatabase.execSQL("insert into profesor values (128, 'Estevan', 'Salar', 'salar@itam.mx', 'profesor');");
        sqLiteDatabase.execSQL("insert into profesor values (129, 'Carmelo', 'Cruz', 'cruz@itam.mx', 'laboratorista');");
        sqLiteDatabase.execSQL("insert into profesor values (130, 'Jorge', 'Díaz', 'díaz@itam.mx', 'profesor');");
        sqLiteDatabase.execSQL("insert into profesor values (131, 'Carlos', 'Lopéz', 'lop@itam.mx', 'estudiante');");
        sqLiteDatabase.execSQL("insert into profesor values (132, 'Rodrigo', 'Juaréz', 'ro@itam.mx', 'laboratorista');");
        //Materias pre-determinadas
        sqLiteDatabase.execSQL("insert into materia values (11, 'Introduccion a la Computación', 'Computacionales');");
        sqLiteDatabase.execSQL("insert into materia values (12, 'Algoritmos y programas', 'Computacionales');");
        sqLiteDatabase.execSQL("insert into materia values (13, 'Desarrollo de Aplicaciones Informáticas', 'Computacionales');");
        sqLiteDatabase.execSQL("insert into materia values (14, 'Diseño Asistido por Computadora', 'Computacionales');");
        sqLiteDatabase.execSQL("insert into materia values (22, 'Cálculo I', 'Matemáticas');");
        sqLiteDatabase.execSQL("insert into materia values (23, 'Cálculo II', 'Matemáticas');");
        sqLiteDatabase.execSQL("insert into materia values (24, 'Cálculo III', 'Matemáticas');");
        sqLiteDatabase.execSQL("insert into materia values (25, 'Cálculo III', 'Matemáticas');");
        sqLiteDatabase.execSQL("insert into materia values (26, 'Algebra Lineal', 'Matemáticas');");
        sqLiteDatabase.execSQL("insert into materia values (27, 'Geometría Analitica', 'Matemáticas');");
        sqLiteDatabase.execSQL("insert into materia values (31, 'Ideas I', 'Estudios Generales');");
        sqLiteDatabase.execSQL("insert into materia values (32, 'Ideas II', 'Estudios Generales');");
        sqLiteDatabase.execSQL("insert into materia values (33, 'Ideas III', 'Estudios Generales');");
        sqLiteDatabase.execSQL("insert into materia values (41, 'Problemas I', 'Estudios Generales');");
        sqLiteDatabase.execSQL("insert into materia values (42, 'Problemas II', 'Estudios Generales');");
        sqLiteDatabase.execSQL("insert into materia values (43, 'Problemas III', 'Estudios Generales');");
        sqLiteDatabase.execSQL("insert into materia values (51, 'Conta I', 'Contabilidad');");
        sqLiteDatabase.execSQL("insert into materia values (52, 'Contabilidad para ingenieros', 'Contabilidad');");
        sqLiteDatabase.execSQL("insert into materia values (61, 'Economía I', 'Economía');");
        sqLiteDatabase.execSQL("insert into materia values (62, 'Economía II', 'Economía');");
        sqLiteDatabase.execSQL("insert into materia values (71, 'Mercadotecnia I', 'Administración');");
        sqLiteDatabase.execSQL("insert into materia values (72, 'Mercadotecnia II', 'Administración');");

        //Clases pre-determinadas
        sqLiteDatabase.execSQL("insert into clase values (1, 11, 023, '9', 'Lunes', 5, 0, 'CC202');");
        sqLiteDatabase.execSQL("insert into clase values (2, 12, 011, '16', 'Martes', 10, 0, 'CC201');");
        sqLiteDatabase.execSQL("insert into clase values (3, 13, 123, '17', 'Jueves', 10, 0, 'CC101');");
        sqLiteDatabase.execSQL("insert into clase values (4, 14, 124, '16', 'Miercoles', 6, 0, 'Salón 301');");
        sqLiteDatabase.execSQL("insert into clase values (5, 22, 125, '8', 'Viernes', 20, 0, 'Salón 201');");
        sqLiteDatabase.execSQL("insert into clase values (6, 23, 126, '10', 'Lunes', 10, 0, 'Salón 213');");
        sqLiteDatabase.execSQL("insert into clase values (7, 24, 127, '10', 'Jueves', 11, 0, 'Salón 311');");
        sqLiteDatabase.execSQL("insert into clase values (8, 25, 128, '11', 'Viernes', 20, 0, 'Salón 311');");
        sqLiteDatabase.execSQL("insert into clase values (9, 26, 129, '15', 'Martes', 5, 0, 'Salón B3');");
        sqLiteDatabase.execSQL("insert into clase values (10, 27, 130, '9', 'Lunes', 20, 0, 'Salón PB2');");
        sqLiteDatabase.execSQL("insert into clase values (11, 31, 131, '9', 'Lunes', 15, 0, 'Salón 101');");
        sqLiteDatabase.execSQL("insert into clase values (12, 32, 132, '9', 'Lunes', 12, 0, 'Salón 102');");
        sqLiteDatabase.execSQL("insert into clase values (13, 33, 128, '7', 'Viernes', 20, 0, 'Salón 311');");
        sqLiteDatabase.execSQL("insert into clase values (14,41, 129, '15', 'Martes', 5, 0, 'Salón B3');");
        sqLiteDatabase.execSQL("insert into clase values (15, 42, 130, '14', 'Lunes', 20, 0, 'Salón PB2');");
        sqLiteDatabase.execSQL("insert into clase values (16, 43, 131, '13', 'Viernes', 15, 0, 'Salón 104');");
        sqLiteDatabase.execSQL("insert into clase values (17, 51, 132, '12', 'Martes', 12, 0, 'Salón 103');");
        sqLiteDatabase.execSQL("insert into clase values (18,61, 023, '12', 'Martes', 15, 0, 'Salón B3');");
        sqLiteDatabase.execSQL("insert into clase values (19, 62, 011, '18', 'Lunes', 30, 0, 'Salón 305');");
        sqLiteDatabase.execSQL("insert into clase values (20, 71, 123, '8', 'Viernes', 17, 0, 'Salón 307');");
        sqLiteDatabase.execSQL("insert into clase values (21, 72, 124, '12', 'Lunes', 12, 0, 'Salón 310');");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists usuario;");
        sqLiteDatabase.execSQL("drop table if exists profesor;");
        sqLiteDatabase.execSQL("drop table if exists materia;");
        sqLiteDatabase.execSQL("drop table if exists clase;");
        sqLiteDatabase.execSQL("drop table if exists calificacion;");
        sqLiteDatabase.execSQL("drop table if exists inscrito;");

//Crear tablas del modelo
        sqLiteDatabase.execSQL("create table usuario (cu integer primary key, nombre text, apellidos text, edad integer, mail text, carrera text, contrasena text);");
        sqLiteDatabase.execSQL("create table profesor (cProfesor integer primary key, nombre text, apellidos text, mail text, tipo text);");
        sqLiteDatabase.execSQL("create table materia (cMateria integer primary key, nombre text, tipo text);");
        sqLiteDatabase.execSQL("create table clase (cClase integer primary key, cMateria integer references materia(cMateria), cProfesor integer references profesor(cProfesor), horario integer, dia text, cupo integer, inscritos integer, lugar text);");
        sqLiteDatabase.execSQL("create table calificacion (cu integer references usuario(cu), cProfesor integer references profesor(cProfesor), puntaje integer, comentario text, primary key (cu, cProfesor));");
        sqLiteDatabase.execSQL("create table inscrito (cClase integer references clase(cClase), cu integer references usuario(cu), primary key (cClase, cu));");
        //Profesores determinados para ponerlos en la aplicación
        sqLiteDatabase.execSQL("insert into profesor values (023, 'Ricardo', 'Meadowcroft', 'rmeadowc@itam.mx', 'estudiante');");
        sqLiteDatabase.execSQL("insert into profesor values (011, 'Ana Lidia', 'Franzoni', 'alidia@itam.mx', 'profesor');");
        sqLiteDatabase.execSQL("insert into profesor values (123, 'Roberto', 'Tello', 'tyo@itam.mx', 'laboratorista');");
        sqLiteDatabase.execSQL("insert into profesor values (124, 'Sofia', 'Occhipinti', 'sofi@itam.mx', 'estudiante');");
        sqLiteDatabase.execSQL("insert into profesor values (125, 'Caro', 'Marti', 'carmar@itam.mx', 'laboratorista');");
        sqLiteDatabase.execSQL("insert into profesor values (126, 'Estela', 'Romero', 'romero@itam.mx', 'profesor');");
        sqLiteDatabase.execSQL("insert into profesor values (127, 'Michelle', 'Desdier', 'desdier@itam.mx', 'estudiante');");
        sqLiteDatabase.execSQL("insert into profesor values (128, 'Estevan', 'Salar', 'salar@itam.mx', 'profesor');");
        sqLiteDatabase.execSQL("insert into profesor values (129, 'Carmelo', 'Cruz', 'cruz@itam.mx', 'laboratorista');");
        sqLiteDatabase.execSQL("insert into profesor values (130, 'Jorge', 'Díaz', 'díaz@itam.mx', 'profesor');");
        sqLiteDatabase.execSQL("insert into profesor values (131, 'Carlos', 'Lopéz', 'lop@itam.mx', 'estudiante');");
        sqLiteDatabase.execSQL("insert into profesor values (132, 'Rodrigo', 'Juaréz', 'ro@itam.mx', 'laboratorista');");
        //Materias pre-determinadas
        sqLiteDatabase.execSQL("insert into materia values (11, 'Introduccion a la Computación', 'Computacionales');");
        sqLiteDatabase.execSQL("insert into materia values (12, 'Algoritmos y programas', 'Computacionales');");
        sqLiteDatabase.execSQL("insert into materia values (13, 'Desarrollo de Aplicaciones Informáticas', 'Computacionales');");
        sqLiteDatabase.execSQL("insert into materia values (14, 'Diseño Asistido por Computadora', 'Computacionales');");
        sqLiteDatabase.execSQL("insert into materia values (22, 'Cálculo I', 'Matemáticas');");
        sqLiteDatabase.execSQL("insert into materia values (23, 'Cálculo II', 'Matemáticas');");
        sqLiteDatabase.execSQL("insert into materia values (24, 'Cálculo III', 'Matemáticas');");
        sqLiteDatabase.execSQL("insert into materia values (25, 'Cálculo III', 'Matemáticas');");
        sqLiteDatabase.execSQL("insert into materia values (26, 'Algebra Lineal', 'Matemáticas');");
        sqLiteDatabase.execSQL("insert into materia values (27, 'Geometría Analitica', 'Matemáticas');");
        sqLiteDatabase.execSQL("insert into materia values (31, 'Ideas I', 'Estudios Generales');");
        sqLiteDatabase.execSQL("insert into materia values (32, 'Ideas II', 'Estudios Generales');");
        sqLiteDatabase.execSQL("insert into materia values (33, 'Ideas III', 'Estudios Generales');");
        sqLiteDatabase.execSQL("insert into materia values (41, 'Problemas I', 'Estudios Generales');");
        sqLiteDatabase.execSQL("insert into materia values (42, 'Problemas II', 'Estudios Generales');");
        sqLiteDatabase.execSQL("insert into materia values (43, 'Problemas III', 'Estudios Generales');");
        sqLiteDatabase.execSQL("insert into materia values (51, 'Conta I', 'Contabilidad');");
        sqLiteDatabase.execSQL("insert into materia values (52, 'Contabilidad para ingenieros', 'Contabilidad');");
        sqLiteDatabase.execSQL("insert into materia values (61, 'Economía I', 'Economía');");
        sqLiteDatabase.execSQL("insert into materia values (62, 'Economía II', 'Economía');");
        sqLiteDatabase.execSQL("insert into materia values (71, 'Mercadotecnia I', 'Administración');");
        sqLiteDatabase.execSQL("insert into materia values (72, 'Mercadotecnia II', 'Administración');");

        //Clases pre-determinadas
        sqLiteDatabase.execSQL("insert into clase values (1, 11, 023, '9', 'Lunes', 5, 0, 'CC202');");
        sqLiteDatabase.execSQL("insert into clase values (2, 12, 011, '16', 'Martes', 10, 0, 'CC201');");
        sqLiteDatabase.execSQL("insert into clase values (3, 13, 123, '17', 'Jueves', 10, 0, 'CC101');");
        sqLiteDatabase.execSQL("insert into clase values (4, 14, 124, '16', 'Miercoles', 6, 0, 'Salón 301');");
        sqLiteDatabase.execSQL("insert into clase values (5, 22, 125, '8', 'Viernes', 20, 0, 'Salón 201');");
        sqLiteDatabase.execSQL("insert into clase values (6, 23, 126, '10', 'Lunes', 10, 0, 'Salón 213');");
        sqLiteDatabase.execSQL("insert into clase values (7, 24, 127, '10', 'Jueves', 11, 0, 'Salón 311');");
        sqLiteDatabase.execSQL("insert into clase values (8, 25, 128, '11', 'Viernes', 20, 0, 'Salón 311');");
        sqLiteDatabase.execSQL("insert into clase values (9, 26, 129, '15', 'Martes', 5, 0, 'Salón B3');");
        sqLiteDatabase.execSQL("insert into clase values (10, 27, 130, '9', 'Lunes', 20, 0, 'Salón PB2');");
        sqLiteDatabase.execSQL("insert into clase values (11, 31, 131, '9', 'Lunes', 15, 0, 'Salón 101');");
        sqLiteDatabase.execSQL("insert into clase values (12, 32, 132, '9', 'Lunes', 12, 0, 'Salón 102');");
        sqLiteDatabase.execSQL("insert into clase values (13, 33, 128, '7', 'Viernes', 20, 0, 'Salón 311');");
        sqLiteDatabase.execSQL("insert into clase values (14,41, 129, '15', 'Martes', 5, 0, 'Salón B3');");
        sqLiteDatabase.execSQL("insert into clase values (15, 42, 130, '14', 'Lunes', 20, 0, 'Salón PB2');");
        sqLiteDatabase.execSQL("insert into clase values (16, 43, 131, '13', 'Viernes', 15, 0, 'Salón 104');");
        sqLiteDatabase.execSQL("insert into clase values (17, 51, 132, '12', 'Martes', 12, 0, 'Salón 103');");
        sqLiteDatabase.execSQL("insert into clase values (18,61, 023, '12', 'Martes', 15, 0, 'Salón B3');");
        sqLiteDatabase.execSQL("insert into clase values (19, 62, 011, '18', 'Lunes', 30, 0, 'Salón 305');");
        sqLiteDatabase.execSQL("insert into clase values (20, 71, 123, '8', 'Viernes', 17, 0, 'Salón 307');");
        sqLiteDatabase.execSQL("insert into clase values (21, 72, 124, '12', 'Lunes', 12, 0, 'Salón 310');");
    }
}